package com.example.amanbhullar.androidproject;

public class FBData {


        double latitude;
        double longtitude;

        public FBData(double latitude, double longtitude){
            this.latitude = latitude;
            this.longtitude = longtitude;
        }





}
